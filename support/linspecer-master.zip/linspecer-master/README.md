# Beautiful and distinguishable line colors + colormap #
by Jonathan C. Lansey

Plot lots of lines with very distinguishable and aesthetically pleasing colors. Works for 'N' colors

forked from [Matlab Central](http://www.mathworks.com/matlabcentral/fileexchange/42673-beautiful-and-distinguishable-line-colors-+-colormap/content/linspecer.m)


